
    <script src="<?= asset("public/auth/assets/vendor/jquery/jquery-3.2.1.min.js") ?>"></script>
    <script src="<?= asset("public/auth/assets/vendor/bootstrap/js/popper.js") ?>"></script>
    <script src="<?= asset("public/auth/assets/vendor/bootstrap/js/bootstrap.min.js") ?>"></script>
    <script src="<?= asset("public/auth/assets/vendor/select2/select2.min.js") ?>"></script>
    <script src="<?= asset("public/auth/assets/vendor/tilt/tilt.jquery.min.js") ?>"></script>
    <script src="<?= asset("public/auth/assets/js/main.js") ?>"></script>